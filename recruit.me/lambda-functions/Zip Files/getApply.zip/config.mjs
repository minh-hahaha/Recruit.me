export const config = {
    "host"     : "recruitme.cijigmaqmrlt.us-east-1.rds.amazonaws.com",
    "user"     : "recruitme",
    "password" : "recruitme",
    "database" : "recruitme"
}

